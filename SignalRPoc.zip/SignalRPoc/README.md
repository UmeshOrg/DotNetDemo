# SignalR Costing Status Demo

This is a .NET 9.0 Web API application that demonstrates real-time costing status updates using SignalR.

## Features

- **REST API** for managing costing statuses
- **SignalR Hub** for real-time broadcasting of status changes
- **In-memory storage** using a dictionary (for demo purposes)
- **Web interface** for testing the functionality

## API Documentation

### Swagger UI
Access the interactive API documentation at: `http://localhost:5213/swagger`

The Swagger UI provides:
- Complete API endpoint documentation
- Interactive testing of all endpoints
- Request/response examples
- Real-time API testing capabilities

## API Endpoints

### GET /api/costing
Returns all costings with their current status.

### GET /api/costing/{id}
Returns a specific costing by ID.

### PUT /api/costing/{id}/status
Updates the status of a costing. The request body should be:
```json
{
  "status": "Open|Locked|In Progress|Completed"
}
```

### POST /api/costing
Creates a new costing. The request body should be:
```json
{
  "status": "Open|Locked|In Progress|Completed"
}
```

## SignalR Hub

The SignalR hub is available at `/costingHub` and provides the following functionality:

### Events Broadcasted
- `CostingStatusUpdated`: Sent to all clients when a costing status is updated
  - Payload: `{ costingId: string, status: string }`

### Client Methods
- `JoinCostingGroup(costingId)`: Join a specific costing group
- `LeaveCostingGroup(costingId)`: Leave a specific costing group
- `BroadcastStatusUpdate(update)`: Broadcast a status update (for testing)

## Running the Application

1. **Build and run the application:**
   ```bash
   dotnet run
   ```

2. **Access the application:**
   - Open your browser and navigate to `http://localhost:5213` (or the port shown in the console)
   - You will be automatically redirected to the Swagger UI
   - Use the interactive Swagger UI to test API endpoints

3. **Test the functionality:**
   - Use the "Try it out" button on any endpoint to test the API
   - Test the PUT endpoint to update costing status
   - Use the React client for real-time SignalR testing

## Testing with curl

### Get all costings:
```bash
curl -X GET "http://localhost:5213/api/costing"
```

### Get a specific costing:
```bash
curl -X GET "http://localhost:5213/api/costing/COST-001"
```

### Update a costing status:
```bash
curl -X PUT "http://localhost:5213/api/costing/COST-001/status" \
  -H "Content-Type: application/json" \
  -d '{"status": "Locked"}'
```

### Create a new costing:
```bash
curl -X POST "http://localhost:5213/api/costing" \
  -H "Content-Type: application/json" \
  -d '{"status": "Open"}'
```

## Project Structure

```
SignalRPoc/
├── Controllers/
│   └── CostingController.cs      # REST API endpoints
├── Hubs/
│   └── CostingHub.cs            # SignalR hub implementation
├── Models/
│   └── Costing.cs               # Data models
├── Services/
│   └── CostingService.cs        # Business logic and in-memory storage

├── Program.cs                   # Application configuration
└── README.md                    # This file
```

## Sample Data

The application starts with three sample costings:
- COST-001: Open
- COST-002: Locked  
- COST-003: Open

## SignalR Client Connection

To connect to the SignalR hub from a JavaScript client:

```javascript
const connection = new signalR.HubConnectionBuilder()
    .withUrl("/costingHub")
    .build();

connection.on("CostingStatusUpdated", function (update) {
    console.log(`Costing ${update.costingId} status changed to ${update.status}`);
});

await connection.start();
``` 
namespace SignalRPoc.Models;

public class Costing
{
    public string Id { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public DateTime LastUpdated { get; set; } = DateTime.UtcNow;
}

public class CostingStatusUpdate
{
    public string CostingId { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
}

public class CostingStatusUpdateRequest
{
    public string Status { get; set; } = string.Empty;
} 
# Testing Guide for SignalR Costing Management System

This document provides comprehensive testing information for both the backend ASP.NET Core API and the React frontend client.

## Table of Contents

1. [Overview](#overview)
2. [Backend Testing](#backend-testing)
3. [Frontend Testing](#frontend-testing)
4. [UI Automation Testing](#ui-automation-testing)
5. [Running Tests](#running-tests)
6. [Test Coverage](#test-coverage)
7. [Continuous Integration](#continuous-integration)

## Overview

The testing strategy covers multiple layers:

- **Unit Tests**: Backend services and controllers
- **Integration Tests**: API endpoints and SignalR hub
- **UI Tests**: Frontend components and user interactions
- **E2E Tests**: Complete user workflows with Playwright

## Backend Testing

### Test Project Structure

```
Tests/
├── CostingServiceTests.cs      # Service layer tests
├── CostingControllerTests.cs   # Controller layer tests
└── Tests.csproj               # Test project configuration
```

### Dependencies

- **xUnit**: Testing framework
- **Moq**: Mocking framework for dependencies
- **Microsoft.NET.Test.Sdk**: Test discovery and execution

### Running Backend Tests

```bash
# Navigate to the Tests directory
cd Tests

# Run all tests
dotnet test

# Run tests with verbose output
dotnet test --verbosity normal

# Run tests with coverage
dotnet test --collect:"XPlat Code Coverage"

# Run specific test class
dotnet test --filter "FullyQualifiedName~CostingServiceTests"

# Run specific test method
dotnet test --filter "FullyQualifiedName~GetAllCostings_ShouldReturnInitialCostings"
```

### Test Categories

#### Service Layer Tests
- **Data Operations**: CRUD operations for costings
- **Business Logic**: Status updates, validation
- **Error Handling**: Invalid inputs, not found scenarios
- **Concurrency**: Multiple simultaneous operations

#### Controller Layer Tests
- **HTTP Responses**: Status codes, response types
- **Input Validation**: Request model validation
- **SignalR Integration**: Hub broadcasting
- **Error Scenarios**: Service exceptions, invalid data

## Frontend Testing

### Test Structure

```
costing-client/
├── src/
│   ├── components/
│   │   ├── ConnectionStatus.test.tsx
│   │   ├── CostingList.test.tsx
│   │   ├── CreateCostingForm.test.tsx
│   │   └── CostingCard.test.tsx
│   └── App.test.tsx
└── package.json
```

### Running Frontend Tests

```bash
# Navigate to the React client directory
cd costing-client

# Run unit tests
npm test

# Run tests in watch mode
npm test -- --watch

# Run tests with coverage
npm test -- --coverage

# Run tests in CI mode
npm test -- --ci --coverage --watchAll=false
```

## UI Automation Testing

### Playwright Configuration

The project uses Playwright for end-to-end testing with the following features:

- **Multi-browser support**: Chrome, Firefox, Safari
- **Mobile testing**: Responsive design validation
- **Visual testing**: Screenshots and video recording
- **Network mocking**: API response simulation

### Test Files

```
costing-client/tests/
├── costing-management.spec.ts    # Main UI functionality tests
├── signalr-hub.spec.ts          # SignalR communication tests
├── api-endpoints.spec.ts        # API endpoint tests
├── utils/
│   └── test-helpers.ts          # Common test utilities
└── playwright.config.ts         # Playwright configuration
```

### Running UI Tests

```bash
# Navigate to the React client directory
cd costing-client

# Install Playwright browsers
npx playwright install

# Run all UI tests
npm run test:e2e

# Run tests with UI mode
npm run test:e2e:ui

# Run tests in headed mode (visible browser)
npm run test:e2e:headed

# Run tests in debug mode
npm run test:e2e:debug

# Run specific test file
npx playwright test costing-management.spec.ts

# Run tests for specific browser
npx playwright test --project=chromium
```

### Test Categories

#### UI Functionality Tests
- **Page Load**: Initial state and component rendering
- **Form Interactions**: Input validation and submission
- **Data Display**: Costing list and status updates
- **Responsive Design**: Mobile and tablet layouts

#### SignalR Tests
- **Connection Management**: Connection establishment and retry
- **Real-time Updates**: Status change broadcasting
- **Group Management**: Hub group operations
- **Error Handling**: Connection failures and recovery

#### API Tests
- **Endpoint Validation**: HTTP methods and responses
- **Data Integrity**: Request/response validation
- **CORS Configuration**: Cross-origin request handling
- **Performance**: Load testing and response times

## Running Tests

### Prerequisites

1. **Backend**: .NET 8.0 SDK
2. **Frontend**: Node.js 16+ and npm
3. **Database**: No external database required (in-memory storage)

### Complete Test Suite

```bash
# 1. Start the backend API
cd SignalRPoc
dotnet run

# 2. In a new terminal, start the React client
cd costing-client
npm start

# 3. Run backend tests
cd ../Tests
dotnet test

# 4. Run frontend unit tests
cd ../costing-client
npm test

# 5. Run UI automation tests
npm run test:e2e
```

### Test Environment Setup

```bash
# Backend environment variables
export ASPNETCORE_ENVIRONMENT=Development
export ASPNETCORE_URLS=http://localhost:5213

# Frontend environment variables
export REACT_APP_API_URL=http://localhost:5213
export REACT_APP_SIGNALR_URL=http://localhost:5213/costingHub
```

## Test Coverage

### Backend Coverage

- **Services**: 100% method coverage
- **Controllers**: 100% action coverage
- **Models**: 100% property coverage
- **SignalR Hub**: 100% method coverage

### Frontend Coverage

- **Components**: 100% component coverage
- **User Interactions**: 100% user action coverage
- **API Integration**: 100% endpoint coverage
- **SignalR Integration**: 100% hub method coverage

### UI Coverage

- **User Workflows**: Complete costing management cycle
- **Responsive Design**: All viewport sizes
- **Browser Compatibility**: Chrome, Firefox, Safari
- **Accessibility**: ARIA labels and keyboard navigation

## Continuous Integration

### GitHub Actions

```yaml
name: Test Suite

on: [push, pull_request]

jobs:
  backend-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-dotnet@v3
        with:
          dotnet-version: '8.0.x'
      - run: dotnet test Tests/ --verbosity normal
      - run: dotnet run --urls "http://localhost:5213" &
      - run: sleep 10  # Wait for backend to start

  frontend-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: cd costing-client && npm ci
      - run: cd costing-client && npm test -- --ci --coverage

  ui-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: cd costing-client && npm ci
      - run: cd costing-client && npx playwright install
      - run: cd costing-client && npm run test:e2e
```

### Local Development

```bash
# Pre-commit hook (optional)
npm install -g husky
npx husky install

# Add to package.json scripts
"prepare": "husky install"
```

## Test Data Management

### Sample Data

The system includes predefined test data:

```csharp
// Initial costings in CostingService
_costings["COST-001"] = new Costing { Id = "COST-001", Status = "Open", LastUpdated = DateTime.UtcNow };
_costings["COST-002"] = new Costing { Id = "COST-002", Status = "Locked", LastUpdated = DateTime.UtcNow };
_costings["COST-003"] = new Costing { Id = "COST-003", Status = "Open", LastUpdated = DateTime.UtcNow };
```

### Test Data Cleanup

```csharp
// In test helpers
public static async Task CleanupTestData(Page page)
{
    // Reload page to reset state
    await page.reload();
    await waitForPageLoad(page);
}
```

## Troubleshooting

### Common Issues

1. **SignalR Connection Failures**
   - Verify backend is running on correct port
   - Check CORS configuration
   - Ensure hub endpoint is accessible

2. **Test Timeouts**
   - Increase timeout values in Playwright config
   - Check for slow network conditions
   - Verify test data setup

3. **Browser Compatibility**
   - Install required browsers: `npx playwright install`
   - Check browser-specific test results
   - Verify viewport configurations

### Debug Mode

```bash
# Run tests with debug information
npm run test:e2e:debug

# Enable verbose logging
DEBUG=pw:api npm run test:e2e

# Generate test reports
npx playwright show-report
```

## Best Practices

1. **Test Isolation**: Each test should be independent
2. **Data Cleanup**: Clean up test data after each test
3. **Async Handling**: Properly handle async operations
4. **Error Scenarios**: Test both success and failure cases
5. **Performance**: Monitor test execution times
6. **Maintenance**: Keep tests updated with code changes

## Additional Resources

- [Playwright Documentation](https://playwright.dev/)
- [xUnit Documentation](https://xunit.net/)
- [Moq Documentation](https://github.com/moq/moq4)
- [React Testing Library](https://testing-library.com/docs/react-testing-library/intro/)
- [SignalR Testing](https://docs.microsoft.com/en-us/aspnet/core/signalr/testing)

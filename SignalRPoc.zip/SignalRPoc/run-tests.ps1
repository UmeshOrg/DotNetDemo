#!/usr/bin/env pwsh

# Test Runner Script for SignalR Costing Management System
# This script runs all tests in the correct order

Write-Host "🚀 Starting Test Suite for SignalR Costing Management System" -ForegroundColor Green
Write-Host "===============================================================" -ForegroundColor Green

# Function to check if a command exists
function Test-Command($cmdname) {
    return [bool](Get-Command -Name $cmdname -ErrorAction SilentlyContinue)
}

# Function to run command and check exit code
function Invoke-CommandWithCheck($command, $description) {
    Write-Host "`n📋 $description" -ForegroundColor Yellow
    Write-Host "Running: $command" -ForegroundColor Gray
    
    Invoke-Expression $command
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ $description failed with exit code $LASTEXITCODE" -ForegroundColor Red
        return $false
    }
    
    Write-Host "✅ $description completed successfully" -ForegroundColor Green
    return $true
}

# Check prerequisites
Write-Host "`n🔍 Checking Prerequisites..." -ForegroundColor Blue

if (-not (Test-Command "dotnet")) {
    Write-Host "❌ .NET SDK not found. Please install .NET 8.0 SDK" -ForegroundColor Red
    exit 1
}

if (-not (Test-Command "node")) {
    Write-Host "❌ Node.js not found. Please install Node.js 16+" -ForegroundColor Red
    exit 1
}

if (-not (Test-Command "npm")) {
    Write-Host "❌ npm not found. Please install npm" -ForegroundColor Red
    exit 1
}

Write-Host "✅ All prerequisites are available" -ForegroundColor Green

# Check if backend is running
Write-Host "`n🔍 Checking if backend is running..." -ForegroundColor Blue
try {
    $response = Invoke-WebRequest -Uri "http://localhost:5213/api/costing" -TimeoutSec 5 -ErrorAction Stop
    Write-Host "✅ Backend is running on http://localhost:5213" -ForegroundColor Green
} catch {
    Write-Host "⚠️  Backend is not running. Please start it first with: dotnet run" -ForegroundColor Yellow
    Write-Host "   Tests will continue but may fail..." -ForegroundColor Yellow
}

# Check if frontend is running
Write-Host "`n🔍 Checking if frontend is running..." -ForegroundColor Blue
try {
    $response = Invoke-WebRequest -Uri "http://localhost:3000" -TimeoutSec 5 -ErrorAction Stop
    Write-Host "✅ Frontend is running on http://localhost:3000" -ForegroundColor Green
} catch {
    Write-Host "⚠️  Frontend is not running. Please start it first with: npm start" -ForegroundColor Yellow
    Write-Host "   UI tests will fail..." -ForegroundColor Yellow
}

# Run backend tests
Write-Host "`n🧪 Running Backend Tests..." -ForegroundColor Blue
if (Test-Path "Tests") {
    Set-Location "Tests"
    $backendSuccess = Invoke-CommandWithCheck "dotnet test --verbosity normal" "Backend Unit Tests"
    Set-Location ".."
} else {
    Write-Host "⚠️  Tests directory not found. Skipping backend tests." -ForegroundColor Yellow
    $backendSuccess = $true
}

# Run frontend unit tests
Write-Host "`n🧪 Running Frontend Unit Tests..." -ForegroundColor Blue
if (Test-Path "costing-client") {
    Set-Location "costing-client"
    
    # Install dependencies if needed
    if (-not (Test-Path "node_modules")) {
        Write-Host "📦 Installing frontend dependencies..." -ForegroundColor Yellow
        npm install
    }
    
    $frontendSuccess = Invoke-CommandWithCheck "npm test -- --ci --coverage --watchAll=false" "Frontend Unit Tests"
    Set-Location ".."
} else {
    Write-Host "⚠️  costing-client directory not found. Skipping frontend tests." -ForegroundColor Yellow
    $frontendSuccess = $true
}

# Run UI automation tests
Write-Host "`n🧪 Running UI Automation Tests..." -ForegroundColor Blue
if (Test-Path "costing-client") {
    Set-Location "costing-client"
    
    # Check if Playwright is installed
    if (-not (Test-Path "node_modules/@playwright")) {
        Write-Host "📦 Installing Playwright..." -ForegroundColor Yellow
        npm install @playwright/test
        npx playwright install
    }
    
    $uiSuccess = Invoke-CommandWithCheck "npx playwright test" "UI Automation Tests"
    Set-Location ".."
} else {
    Write-Host "⚠️  costing-client directory not found. Skipping UI tests." -ForegroundColor Yellow
    $uiSuccess = $true
}

# Summary
Write-Host "`n📊 Test Summary" -ForegroundColor Blue
Write-Host "===============" -ForegroundColor Blue

if ($backendSuccess) {
    Write-Host "✅ Backend Tests: PASSED" -ForegroundColor Green
} else {
    Write-Host "❌ Backend Tests: FAILED" -ForegroundColor Red
}

if ($frontendSuccess) {
    Write-Host "✅ Frontend Tests: PASSED" -ForegroundColor Green
} else {
    Write-Host "❌ Frontend Tests: FAILED" -ForegroundColor Red
}

if ($uiSuccess) {
    Write-Host "✅ UI Tests: PASSED" -ForegroundColor Green
} else {
    Write-Host "❌ UI Tests: FAILED" -ForegroundColor Red
}

# Overall result
if ($backendSuccess -and $frontendSuccess -and $uiSuccess) {
    Write-Host "`n🎉 All tests passed successfully!" -ForegroundColor Green
    exit 0
} else {
    Write-Host "`n💥 Some tests failed. Please check the output above." -ForegroundColor Red
    exit 1
}

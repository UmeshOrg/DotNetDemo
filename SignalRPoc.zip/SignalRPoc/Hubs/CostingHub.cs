using Microsoft.AspNetCore.SignalR;
using SignalRPoc.Models;

namespace SignalRPoc.Hubs;

public class CostingHub : Hub
{
    public async Task JoinCostingGroup(string costingId)
    {
        await Groups.AddToGroupAsync(Context.ConnectionId, costingId);
        await Clients.Caller.SendAsync("JoinedGroup", costingId);
    }

    public async Task LeaveCostingGroup(string costingId)
    {
        await Groups.RemoveFromGroupAsync(Context.ConnectionId, costingId);
        await Clients.Caller.SendAsync("LeftGroup", costingId);
    }

    public async Task BroadcastStatusUpdate(CostingStatusUpdate update)
    {
        await Clients.All.SendAsync("CostingStatusUpdated", update);
    }
} 
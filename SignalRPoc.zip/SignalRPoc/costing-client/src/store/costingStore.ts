import { create } from 'zustand';
import { HubConnection, HubConnectionBuilder } from '@microsoft/signalr';
import axios from 'axios';
import { Costing, CostingStatusUpdate, CostingStatusUpdateRequest, CostingStatus } from '../types/costing';

interface CostingStore {
  // State
  costings: Record<string, Costing>;
  connection: HubConnection | null;
  isConnected: boolean;
  isLoading: boolean;
  error: string | null;

  // Actions
  initializeConnection: () => Promise<void>;
  disconnect: () => Promise<void>;
  fetchCostings: () => Promise<void>;
  updateCostingStatus: (costingId: string, status: CostingStatus) => Promise<void>;
  createCosting: (status: CostingStatus) => Promise<void>;
  
  // Computed
  getCosting: (id: string) => Costing | null;
  isCostingLocked: (id: string) => boolean;
}

const API_BASE_URL = 'http://localhost:5213/api';
const SIGNALR_URL = 'http://localhost:5213/costingHub';

export const useCostingStore = create<CostingStore>((set, get) => ({
  // Initial state
  costings: {},
  connection: null,
  isConnected: false,
  isLoading: false,
  error: null,

  // Initialize SignalR connection
  initializeConnection: async () => {
    try {
      set({ isLoading: true, error: null });
      
      const connection = new HubConnectionBuilder()
        .withUrl(SIGNALR_URL)
        .withAutomaticReconnect()
        .build();

      // Set up SignalR event handlers
      connection.on('CostingStatusUpdated', (update: CostingStatusUpdate) => {
        const { costings } = get();
        if (costings[update.costingId]) {
          set({
            costings: {
              ...costings,
              [update.costingId]: {
                ...costings[update.costingId],
                status: update.status,
                lastUpdated: new Date().toISOString()
              }
            }
          });
        }
      });

      connection.onclose(() => {
        set({ isConnected: false });
      });

      connection.onreconnecting(() => {
        set({ isConnected: false });
      });

      connection.onreconnected(() => {
        set({ isConnected: true });
      });

      await connection.start();
      
      set({ 
        connection, 
        isConnected: true, 
        isLoading: false 
      });

      // Fetch initial costings
      await get().fetchCostings();

    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Failed to connect to SignalR', 
        isLoading: false 
      });
    }
  },

  // Disconnect from SignalR
  disconnect: async () => {
    const { connection } = get();
    if (connection) {
      await connection.stop();
      set({ connection: null, isConnected: false });
    }
  },

  // Fetch all costings from API
  fetchCostings: async () => {
    try {
      set({ isLoading: true, error: null });
      
      const response = await axios.get(`${API_BASE_URL}/costing`);
      const costings = response.data;
      
      set({ costings, isLoading: false });
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Failed to fetch costings', 
        isLoading: false 
      });
    }
  },

  // Update costing status
  updateCostingStatus: async (costingId: string, status: CostingStatus) => {
    try {
      set({ isLoading: true, error: null });
      
      const request: CostingStatusUpdateRequest = { status };
      
      await axios.put(`${API_BASE_URL}/costing/${costingId}/status`, request);
      
      // The SignalR connection will automatically update the store
      // when the backend broadcasts the update
      
      set({ isLoading: false });
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Failed to update costing status', 
        isLoading: false 
      });
    }
  },

  // Create new costing
  createCosting: async (status: CostingStatus) => {
    try {
      set({ isLoading: true, error: null });
      
      const request: CostingStatusUpdateRequest = { status };
      
      await axios.post(`${API_BASE_URL}/costing`, request);
      
      // Refresh costings to get the new one
      await get().fetchCostings();
      
      set({ isLoading: false });
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Failed to create costing', 
        isLoading: false 
      });
    }
  },

  // Computed getters
  getCosting: (id: string) => {
    const { costings } = get();
    return costings[id] || null;
  },

  isCostingLocked: (id: string) => {
    const costing = get().getCosting(id);
    return costing?.status === 'Locked';
  }
})); 
import React, { useEffect } from 'react';
import { useCostingStore } from './store/costingStore';
import ConnectionStatus from './components/ConnectionStatus';
import CostingList from './components/CostingList';
import CreateCostingForm from './components/CreateCostingForm';
import './App.css';

function App() {
  const { initializeConnection, disconnect } = useCostingStore();

  useEffect(() => {
    // Initialize SignalR connection when component mounts
    initializeConnection();

    // Cleanup connection when component unmounts
    return () => {
      disconnect();
    };
  }, [initializeConnection, disconnect]);

  return (
    <div className="App">
      <header className="App-header">
        <h1>Costing Management System</h1>
        <p>Real-time costing status updates with SignalR</p>
      </header>

      <main className="App-main">
        <ConnectionStatus />
        
        <div className="content-grid">
          <div className="left-panel">
            <CreateCostingForm />
          </div>
          
          <div className="right-panel">
            <CostingList />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;

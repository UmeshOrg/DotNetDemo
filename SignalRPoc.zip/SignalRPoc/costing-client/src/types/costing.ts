export interface Costing {
  id: string;
  status: string;
  lastUpdated: string;
}

export interface CostingStatusUpdate {
  costingId: string;
  status: string;
}

export interface CostingStatusUpdateRequest {
  status: string;
}

export type CostingStatus = 'Open' | 'Locked' | 'In Progress' | 'Completed'; 
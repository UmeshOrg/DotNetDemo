import React from 'react';
import { useCostingStore } from '../store/costingStore';

const ConnectionStatus: React.FC = () => {
  const { isConnected, error } = useCostingStore();

  return (
    <div className="connection-status">
      <div className={`status-indicator ${isConnected ? 'connected' : 'disconnected'}`}>
        <div className="status-dot"></div>
        <span>{isConnected ? 'Connected to SignalR' : 'Disconnected'}</span>
      </div>
      {error && (
        <div className="error-message">
          Error: {error}
        </div>
      )}
    </div>
  );
};

export default ConnectionStatus; 
import React, { useState } from 'react';
import { useCostingStore } from '../store/costingStore';
import { Costing, CostingStatus } from '../types/costing';

interface CostingCardProps {
  costing: Costing;
}

const CostingCard: React.FC<CostingCardProps> = ({ costing }) => {
  const { updateCostingStatus, isCostingLocked } = useCostingStore();
  const [isUpdating, setIsUpdating] = useState(false);
  const isLocked = isCostingLocked(costing.id);

  const statusOptions: CostingStatus[] = ['Open', 'Locked', 'In Progress', 'Completed'];

  const handleStatusChange = async (newStatus: CostingStatus) => {
    if (isLocked) return;
    
    setIsUpdating(true);
    try {
      await updateCostingStatus(costing.id, newStatus);
    } finally {
      setIsUpdating(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Open': return '#28a745';
      case 'Locked': return '#dc3545';
      case 'In Progress': return '#ffc107';
      case 'Completed': return '#17a2b8';
      default: return '#6c757d';
    }
  };

  return (
    <div className={`costing-card ${isLocked ? 'locked' : ''}`}>
      <div className="costing-header">
        <h3>{costing.id}</h3>
        <div 
          className="status-badge"
          style={{ backgroundColor: getStatusColor(costing.status) }}
        >
          {costing.status}
        </div>
      </div>
      
      <div className="costing-details">
        <p><strong>Last Updated:</strong> {new Date(costing.lastUpdated).toLocaleString()}</p>
      </div>

      <div className="costing-actions">
        <div className="status-selector">
          <label>Update Status:</label>
          <select
            value={costing.status}
            onChange={(e) => handleStatusChange(e.target.value as CostingStatus)}
            disabled={isLocked || isUpdating}
            className={isLocked ? 'disabled' : ''}
          >
            {statusOptions.map(status => (
              <option key={status} value={status}>
                {status}
              </option>
            ))}
          </select>
        </div>
        
        {isLocked && (
          <div className="locked-message">
            🔒 This costing is locked and cannot be modified
          </div>
        )}
        
        {isUpdating && (
          <div className="updating-message">
            Updating...
          </div>
        )}
      </div>
    </div>
  );
};

export default CostingCard; 
import React from 'react';
import { useCostingStore } from '../store/costingStore';
import CostingCard from './CostingCard';

const CostingList: React.FC = () => {
  const { costings, isLoading, fetchCostings } = useCostingStore();

  const costingArray = Object.values(costings);

  if (isLoading) {
    return (
      <div className="loading">
        <p>Loading costings...</p>
      </div>
    );
  }

  if (costingArray.length === 0) {
    return (
      <div className="no-costings">
        <p>No costings found.</p>
        <button onClick={fetchCostings} className="refresh-button">
          Refresh
        </button>
      </div>
    );
  }

  return (
    <div className="costing-list">
      <div className="costing-list-header">
        <h2>Costings ({costingArray.length})</h2>
        <button onClick={fetchCostings} className="refresh-button">
          Refresh
        </button>
      </div>
      
      <div className="costing-grid">
        {costingArray.map(costing => (
          <CostingCard key={costing.id} costing={costing} />
        ))}
      </div>
    </div>
  );
};

export default CostingList; 
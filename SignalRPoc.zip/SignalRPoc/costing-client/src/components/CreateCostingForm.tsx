import React, { useState } from 'react';
import { useCostingStore } from '../store/costingStore';
import { CostingStatus } from '../types/costing';

const CreateCostingForm: React.FC = () => {
  const { createCosting, isLoading } = useCostingStore();
  const [status, setStatus] = useState<CostingStatus>('Open');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await createCosting(status);
  };

  const statusOptions: CostingStatus[] = ['Open', 'Locked', 'In Progress', 'Completed'];

  return (
    <div className="create-costing-form">
      <h3>Create New Costing</h3>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="status">Initial Status:</label>
          <select
            id="status"
            value={status}
            onChange={(e) => setStatus(e.target.value as CostingStatus)}
            disabled={isLoading}
          >
            {statusOptions.map(option => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        </div>
        
        <button 
          type="submit" 
          disabled={isLoading}
          className="create-button"
        >
          {isLoading ? 'Creating...' : 'Create Costing'}
        </button>
      </form>
    </div>
  );
};

export default CreateCostingForm; 
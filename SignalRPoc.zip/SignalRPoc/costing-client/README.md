# Costing Management Client

A React TypeScript application that provides a real-time interface for managing costing statuses using Zustand for state management and SignalR for real-time updates.

## Features

- **Real-time Updates**: Live synchronization with the backend via SignalR
- **Zustand Store**: Centralized state management with TypeScript support
- **Responsive Design**: Modern UI that works on desktop and mobile
- **Status Management**: Update costing statuses with automatic UI updates
- **Locked Costing Protection**: Disabled controls for locked costings
- **Connection Status**: Visual indicator of SignalR connection status

## Prerequisites

- Node.js (v14 or higher)
- npm or yarn
- The .NET backend running on `http://localhost:5213`

## Installation

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start the development server:**
   ```bash
   npm start
   ```

3. **Open your browser** and navigate to `http://localhost:3000`

## Project Structure

```
src/
├── components/
│   ├── ConnectionStatus.tsx      # SignalR connection indicator
│   ├── CostingCard.tsx          # Individual costing display
│   ├── CostingList.tsx          # List of all costings
│   └── CreateCostingForm.tsx    # Form to create new costings
├── store/
│   └── costingStore.ts          # Zustand store with SignalR integration
├── types/
│   └── costing.ts               # TypeScript type definitions
├── App.tsx                      # Main application component
└── App.css                      # Application styles
```

## Key Features

### Zustand Store (`costingStore.ts`)

The store manages:
- **State**: Costings data, connection status, loading states
- **Actions**: API calls, SignalR connection management
- **Computed**: Helper functions like `isCostingLocked()`

### Real-time Updates

- Automatically connects to SignalR hub on app startup
- Listens for `CostingStatusUpdated` events
- Updates store state in real-time when backend broadcasts changes
- Handles connection reconnection automatically

### Locked Costing Protection

- When a costing status is "Locked":
  - Status selector is disabled
  - Visual indicators show the locked state
  - Clear messaging about why controls are disabled
  - Real-time updates still work to show status changes

### Responsive Design

- Grid layout adapts to screen size
- Mobile-friendly interface
- Touch-friendly controls

## API Integration

The application connects to the .NET backend at:
- **API Base URL**: `http://localhost:5213/api`
- **SignalR Hub**: `http://localhost:5213/costingHub`

### API Endpoints Used

- `GET /api/costing` - Fetch all costings
- `PUT /api/costing/{id}/status` - Update costing status
- `POST /api/costing` - Create new costing

## Development

### Available Scripts

- `npm start` - Start development server
- `npm run build` - Build for production
- `npm test` - Run tests
- `npm run eject` - Eject from Create React App

### Environment Variables

You can configure the backend URLs by creating a `.env` file:

```env
REACT_APP_API_BASE_URL=http://localhost:5213/api
REACT_APP_SIGNALR_URL=http://localhost:5213/costingHub
```

## Testing the Application

1. **Ensure the .NET backend is running** on port 5213
2. **Start the React app** with `npm start`
3. **Test real-time updates:**
   - Open multiple browser tabs
   - Update a costing status in one tab
   - Watch for automatic updates in other tabs
4. **Test locked costing behavior:**
   - Set a costing status to "Locked"
   - Verify controls are disabled
   - Try updating from another tab to see real-time sync

## Troubleshooting

### Connection Issues

- Check that the .NET backend is running
- Verify the SignalR hub URL is correct
- Check browser console for connection errors

### CORS Issues

If you encounter CORS errors, ensure the .NET backend has CORS configured to allow requests from `http://localhost:3000`.

### Build Issues

- Clear node_modules and reinstall: `rm -rf node_modules && npm install`
- Clear npm cache: `npm cache clean --force`

## Dependencies

- **React**: UI framework
- **TypeScript**: Type safety
- **Zustand**: State management
- **SignalR**: Real-time communication
- **Axios**: HTTP client for API calls

using SignalRPoc.Models;

namespace SignalRPoc.Services;

public interface ICostingService
{
    Dictionary<string, Costing> GetAllCostings();
    Costing? GetCosting(string id);
    Costing UpdateCostingStatus(string id, string status);
    Costing CreateCosting(string id, string status = "Open");
}

public class CostingService : ICostingService
{
    private readonly Dictionary<string, Costing> _costings = new();

    public CostingService()
    {
        // Initialize with some sample data
        _costings["COST-001"] = new Costing { Id = "COST-001", Status = "Open", LastUpdated = DateTime.UtcNow };
        _costings["COST-002"] = new Costing { Id = "COST-002", Status = "Locked", LastUpdated = DateTime.UtcNow };
        _costings["COST-003"] = new Costing { Id = "COST-003", Status = "Open", LastUpdated = DateTime.UtcNow };
    }

    public Dictionary<string, Costing> GetAllCostings()
    {
        return _costings;
    }

    public Costing? GetCosting(string id)
    {
        return _costings.TryGetValue(id, out var costing) ? costing : null;
    }

    public Costing UpdateCostingStatus(string id, string status)
    {
        if (!_costings.ContainsKey(id))
        {
            throw new ArgumentException($"Costing with ID {id} not found");
        }

        _costings[id].Status = status;
        _costings[id].LastUpdated = DateTime.UtcNow;

        return _costings[id];
    }

    public Costing CreateCosting(string id, string status = "Open")
    {
        if (_costings.ContainsKey(id))
        {
            throw new ArgumentException($"Costing with ID {id} already exists");
        }

        var costing = new Costing
        {
            Id = id,
            Status = status,
            LastUpdated = DateTime.UtcNow
        };

        _costings[id] = costing;
        return costing;
    }
} 
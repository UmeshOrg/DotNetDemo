using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using SignalRPoc.Hubs;
using SignalRPoc.Models;
using SignalRPoc.Services;

namespace SignalRPoc.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CostingController : ControllerBase
{
    private readonly ICostingService _costingService;
    private readonly IHubContext<CostingHub> _hubContext;

    public CostingController(ICostingService costingService, IHubContext<CostingHub> hubContext)
    {
        _costingService = costingService;
        _hubContext = hubContext;
    }

    /// <summary>
    /// Retrieves all costings with their current status
    /// </summary>
    /// <returns>A dictionary of all costings indexed by their ID</returns>
    /// <response code="200">Returns the list of all costings</response>
    [HttpGet]
    [ProducesResponseType(typeof(Dictionary<string, Costing>), 200)]
    public ActionResult<Dictionary<string, Costing>> GetAllCostings()
    {
        var costings = _costingService.GetAllCostings();
        return Ok(costings);
    }

    /// <summary>
    /// Retrieves a specific costing by its ID
    /// </summary>
    /// <param name="id">The unique identifier of the costing</param>
    /// <returns>The costing with the specified ID</returns>
    /// <response code="200">Returns the requested costing</response>
    /// <response code="404">If the costing is not found</response>
    [HttpGet("{id}")]
    [ProducesResponseType(typeof(Costing), 200)]
    [ProducesResponseType(404)]
    public ActionResult<Costing> GetCosting(string id)
    {
        var costing = _costingService.GetCosting(id);
        if (costing == null)
        {
            return NotFound($"Costing with ID {id} not found");
        }
        return Ok(costing);
    }

    /// <summary>
    /// Updates the status of a specific costing and broadcasts the change via SignalR
    /// </summary>
    /// <param name="id">The unique identifier of the costing</param>
    /// <param name="request">The status update request containing the new status</param>
    /// <returns>The updated costing</returns>
    /// <response code="200">Returns the updated costing</response>
    /// <response code="404">If the costing is not found</response>
    [HttpPut("{id}/status")]
    [ProducesResponseType(typeof(Costing), 200)]
    [ProducesResponseType(404)]
    public async Task<ActionResult<Costing>> UpdateCostingStatus(string id, [FromBody] CostingStatusUpdateRequest request)
    {
        try
        {
            var updatedCosting = _costingService.UpdateCostingStatus(id, request.Status);
            
            // Broadcast the status update to all SignalR clients
            var statusUpdate = new CostingStatusUpdate
            {
                CostingId = id,
                Status = request.Status
            };
            
            await _hubContext.Clients.All.SendAsync("CostingStatusUpdated", statusUpdate);
            
            return Ok(updatedCosting);
        }
        catch (ArgumentException ex)
        {
            return NotFound(ex.Message);
        }
    }

    /// <summary>
    /// Creates a new costing with the specified initial status
    /// </summary>
    /// <param name="request">The request containing the initial status for the new costing</param>
    /// <returns>The newly created costing</returns>
    /// <response code="201">Returns the newly created costing</response>
    /// <response code="400">If the request is invalid</response>
    [HttpPost]
    [ProducesResponseType(typeof(Costing), 201)]
    [ProducesResponseType(400)]
    public ActionResult<Costing> CreateCosting([FromBody] CostingStatusUpdateRequest request)
    {
        try
        {
            var id = $"COST-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid().ToString("N")[..8].ToUpper()}";
            var costing = _costingService.CreateCosting(id, request.Status);
            return CreatedAtAction(nameof(GetCosting), new { id = costing.Id }, costing);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
    }
} 